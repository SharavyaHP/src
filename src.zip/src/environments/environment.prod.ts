const protocol = window.location.protocol + '//';
const host = window.location.host;
const port = window.location.port;

export const environment = {
  production: true,
  baseURL:protocol + host
  };