import { element } from 'protractor';
import { WeatherService } from './weather.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  assetsLists:any=[];
  assets:any=[];
  selectedAsset;
  ngOnInit() {
    this.getCurrentWeather()
  }
  cityName: any;
  primaryInfo = {
    name: "",
    main: {
      temperature: "",
      humidity: "",
      pressure: "",
      temp_max: "",
      temp_min: ""
    }
  }
  display: boolean = false;
  weatherInfo = {
    id: "",
    main: "",
    description: ""
  }
  sprinkler: boolean = false;
  lists: any [];
  table: boolean = false;

  constructor(private weatherService: WeatherService) { }
 getWeather() {
    this.weatherService.getWeatherData(this.cityName).subscribe((response: any) => {
      this.display = true;
      this.primaryInfo.name = response.name;
      this.primaryInfo.main = response.main;
      this.weatherInfo = response.weather[0];
      if (this.weatherInfo.main == 'Clear' || this.weatherInfo.main == 'Haze') {
        this.sprinkler = true;
      } else { this.sprinkler = false}
      console.log(response);
     
      this.cityName = "";
      this.table = false;
    })
  }
  

// listAssets(){
//   this.weatherService.getAssets().subscribe((response:any)=>{
//     this.assetsLists = response._embedded.assets;
//     this.assetsLists.map(element=>{
//       this.assets.push({'label':element,'value':element.assetId});
//     })
//     console.log(this.assetsLists);
//     console.log("assets",this.assets);
//   })
//   console.log("selected asset",this.selectedAsset);
  
// }
getCurrentWeather(){
  this.weatherService.getCurrentWeather().subscribe((response:any)=>{
    console.log("Response",response);
  })
}
}
