// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Http } from '@angular/http';


// // const httpOptions = {
// //   headers: new HttpHeaders({'Content-Type': 'application/json'})
// // }

// @Injectable({
//   providedIn: 'root'
// })
// export class WeatherService {
//   constructor(private http: HttpClient) {}

//   getCurrentWeather() {
//    let headers = new HttpHeaders();
//     headers = headers.append('Access-Control-Allow-Origin','*');
//     return this.http.get('https://api.openweathermap.org/data/2.5/weather?lat=1.3521&lon=103.8198'+'&appid=549fef82568daac7617e1b73d80d1d0f',{headers:headers}
//       );
//  //   .map(response => response.json());
//   }
// }