import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(private http: HttpClient) { }
  
  getWeatherData(cityName){
    return this.http.get(`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=d552ce6c574382f49a542d6414701309`);
  }

  getForeCastData(cityName){
    return this.http.get(`https://api.openweathermap.org/data/2.5/forecast?q=${cityName}&appid=d552ce6c574382f49a542d6414701309`);
  }

  getCurrentWeather() {
   return this.http.get('https://api.openweathermap.org/data/2.5/weather?lat=1.3521&lon=103.8198'+'&appid=549fef82568daac7617e1b73d80d1d0f');
}
}
